import sqlite3
import pandas as pd
import tkinter as tk
from tkinter import ttk, messagebox
import pathlib

# ------------------------------------------------------------------
# Configuration
# ------------------------------------------------------------------
DATABASE_FILE = pathlib.Path("employee_performance.db")

GRADES_DATA = [
    {"Grade": "112A", "Minimum": 32240, "Midpoint": 34600, "Maximum": 43700},
    {"Grade": "113A", "Minimum": 32240, "Midpoint": 38000, "Maximum": 48000},
    {"Grade": "114A", "Minimum": 32800, "Midpoint": 41900, "Maximum": 52500},
    {"Grade": "115A", "Minimum": 34400, "Midpoint": 45900, "Maximum": 57600},
    {"Grade": "116A", "Minimum": 38000, "Midpoint": 50600, "Maximum": 63700},
    {"Grade": "117A", "Minimum": 41600, "Midpoint": 55500, "Maximum": 69700},
]
GRADES_DF = pd.DataFrame(GRADES_DATA).set_index("Grade")
SCORE_INCREASE = {1: 0.00, 2: 0.01, 3: 0.02, 4: 0.025, 5: 0.03}

# ------------------------------------------------------------------
# Salary Evaluation Logic
# ------------------------------------------------------------------
def simulate_progression(current_salary, performance_scores):
    salaries = []
    for year, score in enumerate(performance_scores):
        rate = SCORE_INCREASE.get(score, 0.00)
        current_salary *= (1 + rate)
        current_salary = round(current_salary, 2)
        salaries.append(current_salary)
    return salaries

# ------------------------------------------------------------------
# UI
# ------------------------------------------------------------------
def show_salary_projection():
    win = tk.Tk()
    win.title("Salary Projection Viewer")
    win.geometry("1100x500")

    label = ttk.Label(win, text="Select an employee to view salary projection", font=("Montserrat", 14, "bold"))
    label.pack(pady=10)

    tree = ttk.Treeview(win, columns=("ID", "Name", "Grade", "Salary"), show="headings", height=8)
    for col in ("ID", "Name", "Grade", "Salary"):
        tree.heading(col, text=col)
        tree.column(col, width=150)
    tree.pack(pady=10)

    proj_tree = ttk.Treeview(win, columns=("Year 1", "Year 2", "Year 3", "Year 4", "Year 5", "Exceeded Year"), show="headings", height=5)
    for col in proj_tree["columns"]:
        proj_tree.heading(col, text=col)
        proj_tree.column(col, width=150)
    proj_tree.pack(pady=10)

    def load_employees():
        conn = sqlite3.connect(DATABASE_FILE)
        cur = conn.cursor()
        cur.execute("SELECT id, name, grade, current_salary FROM employees")
        for row in cur.fetchall():
            tree.insert("", "end", values=row)
        conn.close()

    def on_select(event):
        for row in proj_tree.get_children():
            proj_tree.delete(row)

        selected = tree.selection()
        if not selected:
            return

        emp_id = tree.item(selected[0])['values'][0]

        conn = sqlite3.connect(DATABASE_FILE)
        cur = conn.cursor()
        cur.execute("SELECT grade, current_salary, score_y1, score_y2, score_y3, score_y4, score_y5 FROM employees WHERE id=?", (emp_id,))
        data = cur.fetchone()
        conn.close()

        if not data:
            return

        grade, base_salary, *scores = data
        scores = [int(s) for s in scores if s is not None]
        if len(scores) != 5:
            messagebox.showerror("Missing Scores", "This employee does not have 5 performance scores.")
            return

        progression = simulate_progression(base_salary, scores)
        max_salary = GRADES_DF.loc[grade, "Maximum"]
        exceeded_year = next((i + 1 for i, val in enumerate(progression) if val > max_salary), "Within Range")
        proj_tree.insert("", "end", values=(*progression, exceeded_year))

    tree.bind("<Double-1>", on_select)
    load_employees()
    footnote = ttk.Label(win, text="* Note: Current salary is considered Year 0.", font=("Arial", 9, "italic"), foreground="gray")
    footnote.pack(pady=(0, 10))

    win.mainloop()

if __name__ == "__main__":
    show_salary_projection()
