import sqlite3
import pathlib
from tkinter import messagebox
import tkinter as tk
from tkinter import ttk

# Grade bands mapping to Maximum Salary
grade_bands = {
    "112A": 43700,
    "113A": 48000,
    "114A": 52500,
    "115A": 57600,
    "116A": 63700,
    "117A": 69700,
}

# Module-level attributes to be set by Tkinter_Skeleton.py
window = None
year_var = None
tree_info = None
tree_forecast = None
forecasted_scores_dict = None

def fetch_records():
    database_file = pathlib.Path("employee_performance.db")
    if not database_file.exists():
        messagebox.showerror("DATABASE ERROR", "Database not found. Closing program.")
        return None

    conn = sqlite3.connect(database_file)
    cur = conn.cursor()
    cur.execute("SELECT id, name, grade, current_salary, score_y1, score_y2, score_y3, score_y4, score_y5 FROM employees;")
    records = cur.fetchall()
    conn.close()
    return records

def generate_report():
    try:
        year = year_var.get()
        if not year:
            year = "1"
        if not year.isdigit():
            messagebox.showerror("Input Error", "Forecast year must be a positive integer (e.g., 1, 5, 10...).")
            return
        year_index = int(year)
        if year_index < 1:
            messagebox.showerror("Input Error", "Forecast year must be at least 1 (e.g., 1, 5, 10...).")
            return

        tree_info.delete(*tree_info.get_children())
        tree_forecast.delete(*tree_forecast.get_children())

        records = fetch_records()
        if not records:
            return

        for emp in records:
            emp_id, name, grade, current_salary = emp[0], emp[1], emp[2], emp[3]
            forecasted_score = forecasted_scores_dict.get(emp_id, 3)

            forecasted_salary = current_salary * (1 + 0.02) ** year_index
            last_year_salary = current_salary * (1 + 0.02) ** (year_index - 1) if year_index > 1 else current_salary

            max_salary = grade_bands.get(grade, 0)
            exceeds_max = "Yes" if forecasted_salary > max_salary else "No"

            tree_info.insert("", "end", values=(emp_id, name, grade, f"${current_salary:,.2f}"))
            tree_forecast.insert("", "end", values=(forecasted_score, f"${forecasted_salary:,.2f}", f"${last_year_salary:,.2f}", exceeds_max))
    except Exception as e:
        messagebox.showerror("Error", f"Failed to generate report: {str(e)}")

def edit_forecast_popup():
    try:
        popup = tk.Toplevel(window)  # Fixed: Use tk.Toplevel(window) instead of window.Toplevel()
        popup.title("Edit Forecasted Score")
        popup.geometry("300x200")

        tk.Label(popup, text="Select Employee ID:").pack(pady=5)
        records = fetch_records()
        emp_ids = [str(emp[0]) for emp in records] if records else []
        emp_var = tk.StringVar()
        emp_menu = ttk.Combobox(popup, textvariable=emp_var, values=emp_ids, state="readonly")
        emp_menu.pack()

        tk.Label(popup, text="Enter New Forecasted Score (1-5):").pack(pady=5)
        score_var = tk.StringVar()
        tk.Entry(popup, textvariable=score_var).pack()

        def save_edit():
            try:
                emp_id = int(emp_var.get())
                score = int(score_var.get())
                if score < 1 or score > 5:
                    raise ValueError
                forecasted_scores_dict[emp_id] = score
                popup.destroy()
                generate_report()
            except:
                messagebox.showerror("Input Error", "Please enter a valid score (1–5).")

        tk.Button(popup, text="Save", command=save_edit).pack(pady=10)
    except Exception as e:
        messagebox.showerror("Error", f"Failed to open edit forecast popup: {str(e)}")

def apply_same_forecast_popup():
    try:
        popup = tk.Toplevel(window)  # Fixed: Use tk.Toplevel(window) instead of window.Toplevel()
        popup.title("Set Same Forecast Score")
        popup.geometry("300x150")

        tk.Label(popup, text="Enter Forecasted Score for All Employees (1–5):").pack(pady=10)
        score_var = tk.StringVar()
        tk.Entry(popup, textvariable=score_var).pack()

        def set_all():
            try:
                score = int(score_var.get())
                if score < 1 or score > 5:
                    raise ValueError
                records = fetch_records()
                if records:
                    for emp in records:
                        forecasted_scores_dict[emp[0]] = score
                popup.destroy()
                generate_report()
            except:
                messagebox.showerror("Input Error", "Please enter a valid score (1–5).")

        tk.Button(popup, text="Apply to All", command=set_all).pack(pady=10)
    except Exception as e:
        messagebox.showerror("Error", f"Failed to open set forecast popup: {str(e)}")